import React, { useState } from "react";
import { FlatList, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

export default function Simulation() {
  const [amount, setAmount] = useState("");
  const [months, setMonths] = useState("");
  const [rate, setRate] = useState(""); // taxa anual (%)
  const [result, setResult] = useState(null);

  const simulate = () => {
    const principal = parseFloat(amount);
    const n = parseInt(months);
    const annualRate = parseFloat(rate) / 100;

    if (!principal || !n || !annualRate) {
      alert("Please fill all fields correctly.");
      return;
    }

    // taxa de juros efetiva mensal
    const i = Math.pow(1 + annualRate, 1 / 12) - 1;

    // cálculo da parcela fixa (Price)
    const pmt = principal * (i * Math.pow(1 + i, n)) / (Math.pow(1 + i, n) - 1);

    let saldo = principal;
    let memory = [];

    for (let m = 1; m <= n; m++) {
      let juros = saldo * i;
      let amortizacao = pmt - juros;
      saldo -= amortizacao;

      memory.push({
        mes: m,
        juros: juros.toFixed(2),
        amortizacao: amortizacao.toFixed(2),
        saldo: saldo > 0 ? saldo.toFixed(2) : "0.00",
      });
    }

    setResult({
      monthlyRate: (i * 100).toFixed(2),
      totalWithInterest: (pmt * n).toFixed(2),
      installment: pmt.toFixed(2),
      memory,
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Simulador de Emepréstimo</Text>

      {/* Formulário */}
      <TextInput
        style={styles.input}
        placeholder="Loan Amount"
        keyboardType="numeric"
        value={amount}
        onChangeText={setAmount}
      />
      <TextInput
        style={styles.input}
        placeholder="Number of Months"
        keyboardType="numeric"
        value={months}
        onChangeText={setMonths}
      />
      <TextInput
        style={styles.input}
        placeholder="Annual Interest Rate (%)"
        keyboardType="numeric"
        value={rate}
        onChangeText={setRate}
      />

      <TouchableOpacity style={styles.button} onPress={simulate}>
        <Text style={styles.buttonText}>Simular</Text>
      </TouchableOpacity>

      {/* Resultado */}
      {result && (
        <ScrollView style={styles.result}>
          <Text style={styles.resultTitle}>Simulation Result</Text>
          <Text>Effective Monthly Rate: {result.monthlyRate}%</Text>
          <Text>Total with Interest: R$ {result.totalWithInterest}</Text>
          <Text>Monthly Installment: R$ {result.installment}</Text>

          <Text style={styles.memoryTitle}>Calculation Memory:</Text>
          <FlatList
            data={result.memory}
            keyExtractor={(item) => item.mes.toString()}
            renderItem={({ item }) => (
              <View style={styles.memoryRow}>
                <Text>Month {item.mes}</Text>
                <Text>Interest: R$ {item.juros}</Text>
                <Text>Amortization: R$ {item.amortizacao}</Text>
                <Text>Balance: R$ {item.saldo}</Text>
              </View>
            )}
          />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fbff",
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 16,
    color: "#111827",
  },
  input: {
    padding: 12,
    marginBottom: 12,
    backgroundColor: "#FFF",
    height: 40,
    borderRadius: 8,
    paddingHorizontal: 8,
    borderWidth: 0,      // Remove borda
    borderColor: 'transparent', // Garante que não apareça cor de borda
  },
  button: {
    backgroundColor: "#2563EB",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 16,
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "600",
  },
  result: {
    marginTop: 12,
    backgroundColor: "#FFF",
    padding: 12,
    borderRadius: 8,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
  },
  memoryTitle: {
    fontSize: 16,
    fontWeight: "600",
    marginTop: 12,
    marginBottom: 8,
  },
  memoryRow: {
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
    paddingVertical: 6,
  },
});
