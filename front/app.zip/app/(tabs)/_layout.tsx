import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { StatusBar } from "expo-status-bar";

export default function TabLayout() {
  return (
    <>
      <StatusBar backgroundColor="#005aa6" style="light" />
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: "#fff",
          tabBarInactiveTintColor: "#d1e0f5",

          tabBarStyle: {
            backgroundColor: "#005aa6",
            borderBottomColor: "red",
          },
          tabBarLabelStyle: {
            fontSize: 12,
            fontWeight: "600",
          },
          headerStyle: {
            backgroundColor: "#005aa6",
          },
          headerTintColor: "#fff", // deixa o texto/ícone do header branco
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: "Início",
            headerTitle: "CAIXA",
            tabBarIcon: ({ color }) => <MaterialCommunityIcons size={28} name="home-outline" color={color} />,
          }}
        />
        <Tabs.Screen
          name="products"
          options={{
            title: "Produtos",
            tabBarIcon: ({ color }) => <MaterialCommunityIcons size={28} name="hand-coin-outline" color={color} />,
            headerShown: false,
          }}
        />
        <Tabs.Screen
          name="simulation"
          options={{
            title: "Simulador",
            tabBarIcon: ({ color }) => <MaterialCommunityIcons size={28} name="calculator" color={color} />,
          }}
        />
      </Tabs>
    </>
  );
}