import { Stack } from 'expo-router';

export const unstable_settings = {
  initialRouteName: 'index',
};

export default function ProductsLayout() {
  return (
    <Stack
        screenOptions={{
          headerStyle: {
            backgroundColor: "#005aa6",
          },
          headerTintColor: "#fff" // deixa o texto/ícone do header branco
        }}
    >
      <Stack.Screen name='index' options={{title: "Produtos"}} />
      <Stack.Screen name='new' options={{title: "Cadastrar Produto", headerBackTitle: "Voltar"}} />
    </Stack>
  );
}
