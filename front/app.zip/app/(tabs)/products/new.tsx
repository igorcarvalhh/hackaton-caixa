import { Alert, Button, SafeAreaView, ScrollView, StyleSheet, TextInput } from "react-native";

export default function NewProduct() {
  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: "#f8fbff"  
    }}>

    <ScrollView style={{
      margin: 24,
    }}>
        <TextInput
          placeholder="Nome do Produto"
          style={styles.input}
          />
        <TextInput
          placeholder="Taxa de Juros Anual (%)"
          keyboardType="decimal-pad"
          style={styles.input}
          />
        <TextInput
          placeholder="Prazo Máximo (em meses)"
          keyboardType="numeric"
          style={styles.input}
          />
        <Button title="Cadastrar" onPress={() => Alert.alert('Simple Button pressed')} />
    </ScrollView>
          </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  input: {
    height: 40,
    marginBottom: 8,
    borderRadius: 8,
    backgroundColor: "white",
    paddingHorizontal: 8,
    borderWidth: 0,      // Remove borda
    borderColor: 'transparent', // Garante que não apareça cor de borda
    padding: 10,
  },
});