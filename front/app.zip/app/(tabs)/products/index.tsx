import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { FlatList, SafeAreaView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  // Substitua pela URL do seu backend
  const API_URL = "https://seu-backend.com/api/produtos";

  useEffect(() => {
    // Simulando dados mockados
    const mockData = [
      { id: 1, nome: "Empréstimo Pessoal", taxaJurosAnual: 12.5, prazoMaximo: 24 },
      { id: 2, nome: "Crédito Estudantil", taxaJurosAnual: 8.2, prazoMaximo: 240 },
      { id: 3, nome: "Financiamento de Casa", taxaJurosAnual: 8.2, prazoMaximo: 240 },
      { id: 4, nome: "Financiamento de Carro", taxaJurosAnual: 10.0, prazoMaximo: 60 },
      { id: 5, nome: "Empréstimo Empresarial", taxaJurosAnual: 10.0, prazoMaximo: 60 },
      { id: 6, nome: "Empréstimo Emergencial", taxaJurosAnual: 6.5, prazoMaximo: 120 },
    ];

    // Simula um pequeno delay (como se fosse a API)
    setTimeout(() => {
      setProducts(mockData);
    }, 1000);
  }, []);

  // if (loading) {
  //   return (
  //     <View style={styles.loader}>
  //       <ActivityIndicator size="large" color="#1976D2" />
  //       <Text>Loading products...</Text>
  //     </View>
  //   );
  // }

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.name}>{item.nome}</Text>
      <Text style={styles.detail}>Taxa de juros anual: {item.taxaJurosAnual}%</Text>
      <Text style={styles.detail}>Prazo máximo: {item.prazoMaximo} meses</Text>
    </View>
  );

  return (
    <SafeAreaView style={{
      flex:1, backgroundColor: "#f8fbff"
    }}>
    <View style={styles.container}>
      <Text style={styles.title}>Produtos de Empréstimo</Text>

      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 100 }} // espaço pro botão
      />

      {/* Botão fixo no rodapé */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/(tabs)/products/new")} // rota /product/new
      >
        <Text style={styles.buttonText}>Cadastrar Produto</Text>
      </TouchableOpacity>
    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 12,
    color: "#111827",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 3,
  },
  name: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1E3A8A",
  },
  detail: {
    fontSize: 14,
    color: "#374151",
    marginTop: 4,
  },
  button: {
    position: "absolute",
    bottom: 20,
    left: 16,
    right: 16,
    backgroundColor: "#2563EB",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    elevation: 5,
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "600",
  },
});